import databases
import sqlalchemy
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import date, timedelta
import logging
import httpx
import random
import boto3
from botocore.exceptions import ClientError
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os
from dotenv import load_dotenv

# Load environment variables from .env file for local development
load_dotenv()

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database setup for SQLite
DATABASE_URL = "sqlite:///calendar.db"

database = databases.Database(DATABASE_URL)
metadata = sqlalchemy.MetaData()

events = sqlalchemy.Table(
    "events",
    metadata,
    sqlalchemy.Column("id", sqlalchemy.Integer, primary_key=True),
    sqlalchemy.Column("event_date", sqlalchemy.String),
    sqlalchemy.Column("content", sqlalchemy.String),
    sqlalchemy.Column("position", sqlalchemy.Integer),
)

engine = sqlalchemy.create_engine(
    DATABASE_URL
)
metadata.create_all(engine)


class Event(BaseModel):
    id: int = None
    event_date: str
    content: str
    position: int

app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

@app.on_event("startup")
async def startup():
    await database.connect()
    logger.info("Database connected")

@app.on_event("shutdown")
async def shutdown():
    await database.disconnect()
    logger.info("Database disconnected")

@app.get("/api/events/{year}/{month}")
async def get_events(year: int, month: int):
    logger.info(f"Getting events for {year}-{month}")
    query = events.select().where(events.c.event_date.like(f"{year}-{month:02d}-%"))
    result = await database.fetch_all(query)
    logger.info(f"Found {len(result)} events")
    return result

@app.post("/api/events")
async def save_event(event: Event):
    logger.info(f"Saving event: {event}")
    query = events.select().where(events.c.event_date == event.event_date).where(events.c.position == event.position)
    existing_event = await database.fetch_one(query)
    if existing_event:
        update_query = events.update().where(events.c.id == existing_event.id).values(content=event.content)
        await database.execute(update_query)
        logger.info(f"Updated existing event with id {existing_event.id}")
        return {**event.dict(), "id": existing_event.id}
    else:
        query = events.insert().values(event_date=event.event_date, content=event.content, position=event.position)
        last_record_id = await database.execute(query)
        logger.info(f"Created new event with id {last_record_id}")
        return {**event.dict(), "id": last_record_id}

@app.get("/api/weather/{latitude}/{longitude}")
async def get_weather(latitude: float, longitude: float, start_date: date, end_date: date):
    logger.info(f"Getting weather for {latitude}, {longitude} from {start_date} to {end_date}")

    today = date.today()
    # Open-Meteo provides 16 days of forecast (today + 15 days)
    max_forecast_date = today + timedelta(days=15)

    # If the requested start date is beyond the forecast limit, return empty.
    if start_date > max_forecast_date:
        logger.warning(f"Requested start date {start_date} is beyond the 16-day forecast limit.")
        return {"daily": {"time": [], "precipitation_probability_mean": []}}

    # Truncate the end_date if it goes beyond the forecast limit.
    api_end_date = min(end_date, max_forecast_date)
    api_start_date = min(start_date, api_end_date)

    # The forecast API only supports up to 92 past days for precipitation probability.
    min_historical_date = today - timedelta(days=92)
    if api_start_date < min_historical_date:
        api_start_date = min_historical_date

    try:
        async with httpx.AsyncClient() as client:
            url = (
                "https://api.open-meteo.com/v1/forecast"
                f"?latitude={latitude}&longitude={longitude}"
                "&daily=precipitation_probability_mean,cloudcover_mean"
                f"&start_date={api_start_date.isoformat()}&end_date={api_end_date.isoformat()}"
            )
            response = await client.get(url)
            response.raise_for_status()
            logger.info("Successfully fetched weather data")
            return response.json()
    except httpx.HTTPStatusError as e:
        logger.error(f"Error fetching weather data: {e} for URL: {e.request.url}")
        return {"error": "Failed to fetch weather data"}, 500
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}")
        return {"error": "An unexpected error occurred"}, 500

@app.get("/api/flights/{origin}/{destination}")
async def get_flight_prices(origin: str, destination: str, start_date: date, end_date: date):
    logger.info(f"Getting flight prices for {origin} to {destination} from {start_date} to {end_date}")
    
    flight_prices = {}
    current_date = start_date
    while current_date <= end_date:
        # Simulate price fluctuations based on day of the week (weekends are more expensive)
        base_price = 250
        if current_date.weekday() >= 4: # Friday, Saturday, Sunday
            base_price += random.randint(50, 150)
        else:
            base_price += random.randint(-25, 50)
        
        # Add some random noise
        price = base_price + random.randint(-20, 20)
        flight_prices[current_date.isoformat()] = max(150, price) # Ensure a minimum price
        current_date += timedelta(days=1)
        
    logger.info(f"Generated {len(flight_prices)} flight prices.")
    return flight_prices

def get_custody_for_day(db_events, a_date):
    """
    Determines the custody schedule for a given day.
    It first checks for a manual override in the events, otherwise falls back to the default schedule.
    """
    # Check for a manually set event for custody (position 4)
    for event in db_events:
        if event['position'] == 4:
            if event['content'] == 'jeff':
                return "Jeff/Rowen"
            elif event['content'] == 'deanna':
                return "Deanna/Rowen"
    
    # Default logic based on day of the week if no event is found
    # In Python, weekday() is Mon=0, Tue=1, ..., Sat=5, Sun=6.
    # The default is Jeff for Sat, Sun, Mon.
    if a_date.weekday() in [0, 5, 6]: # Mon, Sat, Sun
        return "Jeff/Rowen"
    else:
        return "Deanna/Rowen"

@app.post("/api/summary/email")
async def send_email_summary():
    sender_email = "jeff@levensailor.com"
    receiver_email = "jeff@levensailor.com"
    app_password = "geot osxh wdbw mdkn"
    
    summary_lines = []
    today = date.today()
    
    logger.info("Generating 5-day summary for email...")

    for i in range(5):
        current_date = today + timedelta(days=i)
        date_str = current_date.isoformat()
        day_name = current_date.strftime("%a").upper()
        
        all_day_events_query = events.select().where(events.c.event_date == date_str)
        all_day_events_from_db = await database.fetch_all(all_day_events_query)
        
        custody = get_custody_for_day(all_day_events_from_db, current_date)
        
        other_events = [e['content'] for e in all_day_events_from_db if e['position'] != 4 and e['content'] and e['content'].strip()]
        
        line = f"{day_name} ({current_date.month}/{current_date.day}): {custody}"
        if other_events:
            line += " - " + ", ".join(other_events)
        summary_lines.append(line)
        
    summary_text = "\n".join(summary_lines)
    
    # --- Email Sending using G-Suite ---
    try:
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = "Your 5-Day Calendar Summary"
        msg.attach(MIMEText(summary_text, 'plain'))
        
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, app_password)
        server.send_message(msg)
        server.quit()
        
        logger.info(f"Email summary sent successfully to {receiver_email}.")
        return {"status": "email_sent_successfully"}
    except Exception as e:
        logger.error(f"Failed to send email: {e}")
        return {"error": "Failed to send email", "details": str(e)}, 500

@app.get("/api/waves/{latitude}/{longitude}")
async def get_wave_height(latitude: float, longitude: float, start_date: date, end_date: date):
    logger.info(f"Getting wave height for {latitude}, {longitude} from {start_date} to {end_date}")
    
    # The marine API has similar date constraints to the weather API.
    # We'll use a simplified range for this request.
    try:
        async with httpx.AsyncClient() as client:
            url = (
                "https://marine-api.open-meteo.com/v1/marine"
                f"?latitude={latitude}&longitude={longitude}"
                "&daily=wave_height_max"
                f"&start_date={start_date.isoformat()}&end_date={end_date.isoformat()}"
            )
            response = await client.get(url)
            response.raise_for_status()
            logger.info("Successfully fetched wave height data")
            return response.json()
    except httpx.HTTPStatusError as e:
        logger.error(f"Error fetching wave data: {e} for URL: {e.request.url}")
        return {"error": "Failed to fetch wave data"}, 500
    except Exception as e:
        logger.error(f"An unexpected error occurred while fetching wave data: {e}")
        return {"error": "An unexpected error occurred"}, 500

# Mount the frontend
app.mount("/", StaticFiles(directory="dist", html=True), name="static") 