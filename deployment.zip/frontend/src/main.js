import { createApp } from 'vue'
import App from './App.vue'
import './assets/main.css'

console.log("main.js: Starting Vue application");

const app = createApp(App)

app.mount('#app')

console.log("main.js: Vue application mounted"); 