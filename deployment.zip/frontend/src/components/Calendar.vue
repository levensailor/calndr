<template>
  <div class="calendar">
    <div class="calendar-header">
      <div class="day-name" v-for="day in daysOfWeek" :key="day">{{ day }}</div>
    </div>
    <div class="calendar-grid">
      <div 
        class="day-cell" 
        v-for="day in calendarDays" 
        :key="day.date" 
        :class="{ 'other-month': !day.isCurrentMonth }"
      >
        <WeatherFX
          v-if="showRaindrops"
          :cloud-cover="getCloudCover(day.date)"
          :precipitation="getPrecipitationChance(day.date)"
        />
        <div class="day-header-icons">
          <div class="flight-info" v-if="showFlights && getFlightPrice(day.date)">
            <svg width="14" height="14" viewBox="0 0 24 24"><path fill="currentColor" d="M20.56 3.91C21.15 4.5 21.15 5.45 20.56 6.04L16.5 10.1L13.9 7.5L17.96 3.44C18.55 2.85 19.5 2.85 20.09 3.44L20.56 3.91M15.08 8.92L3.44 20.56C2.85 21.15 2.85 22.1 3.44 22.69L3.91 23.16C4.5 23.75 5.45 23.75 6.04 23.16L17.68 11.52L15.08 8.92M3 15.5L6.5 19L11.5 14L8 10.5L3 15.5Z"></path></svg>
            <span>${{ getFlightPrice(day.date) }}</span>
          </div>
          <div class="wave-info" v-if="showWaves && getWaveInfo(day.date).count > 0">
            <svg v-for="n in getWaveInfo(day.date).count" :key="n" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12h2.5c1 0 1.5-1.5 2.5-1.5s1.5 1.5 2.5 1.5s1.5-1.5 2.5-1.5s1.5 1.5 2.5 1.5s1.5-1.5 2.5-1.5H21"/></svg>
            <span>{{ getWaveInfo(day.date).text }}</span>
          </div>
        </div>
        <div class="day-number">{{ day.day }}</div>
        <div class="events">
          <div
            v-for="n in 4"
            :key="n"
            class="event-placeholder"
            contenteditable="true"
            @blur="saveEvent($event, day.date, n - 1)"
            @keydown.enter.prevent="$event.target.blur()"
            :ref="el => setEventRef(el, day.date, n - 1)"
            v-html="getEventContent(day.date, n - 1)"
          ></div>
          <div
            class="event-placeholder custody-row"
            :class="getCustodyInfo(day.date).class"
            @click="toggleCustody(day.date)"
          >
            <svg class="child-icon" width="16" height="16" viewBox="0 0 64 64" fill="currentColor">
              <path d="M54.26,29.35a21.33,21.33,0,0,0-8.07-11.52A5.56,5.56,0,0,0,44,15.69c2.65-3.61,2.71-4.42,2.74-4.78A2.48,2.48,0,0,0,46,9c-.63-.65-1.94-1.39-4.56-1.24-2.46.14-4.84,2.18-6.22,3.6a5.47,5.47,0,0,0-6.5,0C27.38,9.9,25,7.85,22.53,7.71,19.91,7.56,18.6,8.3,18,9a2.49,2.49,0,0,0-.74,2c0,.35.09,1.17,2.77,4.76a5.3,5.3,0,0,0-2.21,2.21.89.89,0,0,0-.17.08A21.39,21.39,0,0,0,9.74,29.35C7.08,29.7,5,32.3,5,35.46c0,3.33,2.32,6,5.19,6.15,3.06,8.53,11.68,14.7,21.81,14.7s18.75-6.17,21.81-14.7c2.87-.1,5.19-2.82,5.19-6.15C59,32.31,56.92,29.7,54.26,29.35ZM41.58,9.71c2.1-.12,2.84.46,3,.64a.51.51,0,0,1,.18.38,16.75,16.75,0,0,1-2.44,3.88A1.92,1.92,0,0,0,42,16.1a1.88,1.88,0,0,0,.86,1.23c1.19.73,1.62,1.36,1.55,1.59a4.26,4.26,0,0,1-2.11,1.91,3.5,3.5,0,0,1-2.59.37,8.92,8.92,0,0,1-3-2.59,5.7,5.7,0,0,0,.37-.69c.35.14.79.32,1.32.56a1,1,0,0,0,.42.09,1,1,0,0,0,.42-1.9c-.71-.33-1.29-.56-1.72-.72,0-.07,0-.14,0-.21a4.21,4.21,0,0,0,0-.62A13.49,13.49,0,0,1,40,14.4a1,1,0,1,0-.35-2,14,14,0,0,0-2.77.77c-.08-.15-.17-.3-.26-.44C38.4,10.93,40.23,9.78,41.58,9.71ZM32,12.24a3.5,3.5,0,1,1-3.5,3.5A3.5,3.5,0,0,1,32,12.24ZM21.13,17.33A1.88,1.88,0,0,0,22,16.09a1.9,1.9,0,0,0-.33-1.48,17.43,17.43,0,0,1-2.44-3.86.52.52,0,0,1,.18-.4c.18-.18.92-.77,3-.64,1.35.07,3.18,1.22,5,3.06-.09.15-.18.29-.26.44a14.16,14.16,0,0,0-2.77-.77,1,1,0,0,0-1.17.8A1,1,0,0,0,24,14.4a13.18,13.18,0,0,1,2.55.72,4.3,4.3,0,0,0,0,.62c0,.07,0,.14,0,.21-.43.16-1,.39-1.72.72a1,1,0,0,0,.42,1.9,1.06,1.06,0,0,0,.42-.09c.52-.24,1-.43,1.32-.56a5.7,5.7,0,0,0,.37.69,8.92,8.92,0,0,1-3,2.59,3.5,3.5,0,0,1-2.59-.37,4.26,4.26,0,0,1-2.11-1.91C19.51,18.69,19.94,18.06,21.13,17.33ZM7,35.46a4.17,4.17,0,0,1,2.26-3.91,20.08,20.08,0,0,0,.3,7.93A4.07,4.07,0,0,1,7,35.46ZM32,54.31c-11.58,0-21-8.76-21-19.53a18.89,18.89,0,0,1,7-14.56,6.84,6.84,0,0,0,2.81,2.41,6.41,6.41,0,0,0,2.73.69A4,4,0,0,0,25,23.07a10.16,10.16,0,0,0,3.7-3,5.47,5.47,0,0,0,6.66,0,10.24,10.24,0,0,0,3.7,3,4,4,0,0,0,1.43.25,6.41,6.41,0,0,0,2.73-.69A6.84,6.84,0,0,0,46,20.22a18.86,18.86,0,0,1,7,14.56C53,45.55,43.58,54.31,32,54.31ZM54.44,39.48a20.08,20.08,0,0,0,.3-7.93A4.18,4.18,0,0,1,57,35.46,4.06,4.06,0,0,1,54.44,39.48Z"></path> 
              <path d="M23.29,29.7a3.86,3.86,0,0,0-3.61,4.05,1,1,0,0,0,2,0,1.87,1.87,0,0,1,1.61-2.05,1.87,1.87,0,0,1,1.61,2.05,1,1,0,0,0,2,0A3.86,3.86,0,0,0,23.29,29.7Z"></path> 
              <path d="M39.84,29.7a3.86,3.86,0,0,0-3.61,4.05,1,1,0,0,0,2,0,1.87,1.87,0,0,1,1.61-2.05,1.87,1.87,0,0,1,1.61,2.05,1,1,0,0,0,2,0A3.86,3.86,0,0,0,39.84,29.7Z"></path> 
              <path d="M36.35,41a1,1,0,0,0-1,1,3.35,3.35,0,1,1-6.7,0,1,1,0,0,0-2,0,5.35,5.35,0,1,0,10.7,0A1,1,0,0,0,36.35,41Z"></path>
            </svg>
            <span>{{ getCustodyInfo(day.date).text }}</span>
          </div>
        </div>
      </div>
    </div>
    <div class="calendar-footer">
      <div class="footer-icons">
        <button @click="toggleRaindrops" class="icon-button" title="Toggle Weather">
          <svg :class="{ 'active': showRaindrops }" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20 16.58A5 5 0 0 0 18 7h-1.26A8 8 0 1 0 4 15.25"></path>
          </svg>
        </button>
        <button @click="toggleWaves" class="icon-button surfboard-toggle" title="Toggle Waves">
          <svg :class="{ 'active': showWaves }" width="24" height="24" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
            <path d="M4 12l1 8l8 -2.5" />
            <path d="M13 17.5l8 -8a2.121 2.121 0 0 0 -3 -3l-8 8" />
            <path d="M11.5 5.5l1.5 1.5" />
            <path d="M6 10l-2 2" />
          </svg>
        </button>
        <button @click="toggleFlights" class="icon-button flight-toggle" title="Toggle Flights">
          <svg :class="{ 'active': showFlights }" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
            <path d="M16 10h4a2 2 0 0 1 0 4h-4l-4 7h-3l2 -7h-4l-2 2h-3l2 -4l-2 -4h3l2 2h4l-2 -7h3z" />
          </svg>
        </button>
      </div>
      <div class="month-nav">
        <button @click="prevMonth">&lt;</button>
        <span>{{ currentMonthName }} {{ currentYear }}</span>
        <button @click="nextMonth">&gt;</button>
        <div class="custody-share">
          Jeff {{ custodyShare.jeff }}% | Deanna {{ custodyShare.deanna }}%
        </div>
      </div>
      <div class="footer-actions">
        <button @click="sendSummary" class="icon-button" title="Send Email Summary">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
            <rect x="3" y="5" width="18" height="14" rx="2" />
            <polyline points="3 7 12 13 21 7" />
          </svg>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import WeatherFX from './WeatherFX.vue';

export default {
  name: 'Calendar',
  components: {
    WeatherFX,
  },
  data() {
    console.log("Calendar.vue: data() called");
    return {
      currentDate: new Date(),
      daysOfWeek: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
      events: {},
      eventRefs: {},
      weather: {},
      flights: {},
      waves: {},
      showRaindrops: false,
      showFlights: false,
      showWaves: false,
    };
  },
  computed: {
    currentYear() {
      return this.currentDate.getFullYear();
    },
    currentMonth() {
      return this.currentDate.getMonth();
    },
    currentMonthName() {
      return this.currentDate.toLocaleString('default', { month: 'long' });
    },
    calendarDays() {
      console.log("Calendar.vue: computed calendarDays() called");
      try {
        const year = this.currentYear;
        const month = this.currentMonth;
        const firstDayOfMonth = new Date(year, month, 1);
        const lastDayOfMonth = new Date(year, month + 1, 0);
        const firstDayOfWeek = firstDayOfMonth.getDay();
        const lastDayOfMonthDate = lastDayOfMonth.getDate();

        const days = [];
        
        const prevMonthDate = new Date(year, month, 0);
        const prevMonthLastDay = prevMonthDate.getDate();
        const prevMonth = prevMonthDate.getMonth() + 1;
        const prevMonthYear = prevMonthDate.getFullYear();

        // Days from previous month
        for (let i = firstDayOfWeek; i > 0; i--) {
          const day = prevMonthLastDay - i + 1;
          const date = `${prevMonthYear}-${String(prevMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          days.push({ day, date, isCurrentMonth: false });
        }

        // Days of current month
        for (let i = 1; i <= lastDayOfMonthDate; i++) {
          const date = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
          days.push({ day: i, date, isCurrentMonth: true });
        }

        const nextMonthDate = new Date(year, month + 1, 1);
        const nextMonth = nextMonthDate.getMonth() + 1;
        const nextMonthYear = nextMonthDate.getFullYear();

        // Days from next month
        const lastDayOfWeek = lastDayOfMonth.getDay();
        for (let i = 1; i < 7 - lastDayOfWeek; i++) {
           const day = i;
           const date = `${nextMonthYear}-${String(nextMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          days.push({ day, date, isCurrentMonth: false });
        }
        console.log(`Calendar.vue: Generated ${days.length} days for the calendar`);
        return days;
      } catch (error) {
        console.error('Error generating calendar days:', error);
        return [];
      }
    },
    custodyShare() {
      const currentMonthDays = this.calendarDays.filter(day => day.isCurrentMonth);
      const totalDays = currentMonthDays.length;
      if (totalDays === 0) {
        return { jeff: 0, deanna: 0 };
      }

      let jeffDays = 0;
      for (const day of currentMonthDays) {
        const custodyInfo = this.getCustodyInfo(day.date);
        if (custodyInfo.owner === 'jeff') {
          jeffDays++;
        }
      }

      const jeffPercentage = Math.round((jeffDays / totalDays) * 100);
      const deannaPercentage = 100 - jeffPercentage;
      
      return { jeff: jeffPercentage, deanna: deannaPercentage };
    },
  },
  methods: {
    setEventRef(el, date, position) {
      if (el) {
        this.eventRefs[`${date}-${position}`] = el;
      }
    },
    getEventContent(date, position) {
      if (this.events[date] && this.events[date][position]) {
        return this.events[date][position].content || '';
      }
      return '';
    },
    getCloudCover(date) {
        if (!this.weather[date] || !this.weather[date].cloudcover === undefined) return 0;
        return this.weather[date].cloudcover;
    },
    getPrecipitationChance(date) {
      if (!this.weather[date] || this.weather[date].precip === undefined) return 0;
      return this.weather[date].precip;
    },
    getWaveInfo(date) {
        const height = this.waves[date];
        if (height === undefined || height === null) return { count: 0, text: '' };

        if (height < 1) { // Low waves (< 1m)
            return { count: 1, text: `${height.toFixed(1)}m` };
        } else if (height >= 1 && height < 2) { // Medium waves (1-2m)
            return { count: 2, text: `${height.toFixed(1)}m` };
        } else { // High waves (>= 2m)
            return { count: 3, text: `${height.toFixed(1)}m` };
        }
    },
    getFlightPrice(date) {
      return this.flights[date] || null;
    },
    toggleRaindrops() {
      this.showRaindrops = !this.showRaindrops;
    },
    toggleWaves() {
        this.showWaves = !this.showWaves;
    },
    toggleFlights() {
      this.showFlights = !this.showFlights;
    },
    getCustodyInfo(date) {
      const event = (this.events[date] && this.events[date][4]) ? this.events[date][4].content : null;
      // Adding 'T00:00:00' avoids timezone issues when getting the day
      const dayOfWeek = new Date(date + 'T00:00:00').getUTCDay();

      let owner;

      if (event === 'jeff' || event === 'deanna') {
        owner = event;
      } else {
        // Default logic: 0=Sun, 1=Mon, 6=Sat
        owner = [0, 1, 6].includes(dayOfWeek) ? 'jeff' : 'deanna';
      }

      if (owner === 'jeff') {
        return { owner: 'jeff', text: 'Jeff/Rowen', class: 'custody-jeff' };
      } else {
        return { owner: 'deanna', text: 'Deanna/Rowen', class: 'custody-deanna' };
      }
    },
    async toggleCustody(date) {
      const currentInfo = this.getCustodyInfo(date);
      const newOwner = currentInfo.owner === 'jeff' ? 'deanna' : 'jeff';
      const position = 4;

      try {
        const response = await axios.post('/api/events', {
          event_date: date,
          content: newOwner,
          position: position,
        });
        
        const updatedEvents = { ...this.events };
        if (!updatedEvents[date]) {
          updatedEvents[date] = [];
        }
        updatedEvents[date][position] = response.data;
        this.events = updatedEvents;

        console.log("Calendar.vue: Custody event saved successfully");
      } catch (error) {
        console.error('Error saving custody event:', error);
      }
    },
    async fetchWeather() {
      if (this.calendarDays.length === 0) {
        return;
      }
      const startDate = this.calendarDays[0].date;
      const endDate = this.calendarDays[this.calendarDays.length - 1].date;

      console.log(`Calendar.vue: fetchWeather() called for ${startDate} to ${endDate}`);
      try {
        const response = await axios.get(`/api/weather/34.29/-77.97?start_date=${startDate}&end_date=${endDate}`);
        const weatherData = response.data;
        const newWeather = {};
        if (weatherData.daily) {
          weatherData.daily.time.forEach((date, index) => {
            newWeather[date] = {
                precip: weatherData.daily.precipitation_probability_mean[index],
                cloudcover: weatherData.daily.cloudcover_mean[index],
            };
          });
        }
        this.weather = newWeather;
        console.log("Calendar.vue: Weather data fetched successfully", this.weather);
      } catch (error) {
        console.error('Error fetching weather data:', error);
      }
    },
    async fetchFlights() {
      if (this.calendarDays.length === 0) {
        return;
      }
      const startDate = this.calendarDays[0].date;
      const endDate = this.calendarDays[this.calendarDays.length - 1].date;

      console.log(`Calendar.vue: fetchFlights() called for ${startDate} to ${endDate}`);
      try {
        const response = await axios.get(`/api/flights/ILM/AUS?start_date=${startDate}&end_date=${endDate}`);
        this.flights = response.data;
        console.log("Calendar.vue: Flight data fetched successfully", this.flights);
      } catch (error) {
        console.error('Error fetching flight data:', error);
      }
    },
    async fetchEvents() {
      console.log("Calendar.vue: fetchEvents() called");
      try {
        const response = await axios.get(`/api/events/${this.currentYear}/${this.currentMonth + 1}`);
        this.events = {};
        response.data.forEach(event => {
          if (!this.events[event.event_date]) {
            this.events[event.event_date] = [];
          }
          this.events[event.event_date][event.position] = event;
        });
        console.log("Calendar.vue: Events fetched successfully", this.events);
        this.adjustFontSize();
      } catch (error) {
        console.error('Error fetching events:', error);
        // Don't break the app if API fails
      }
    },
    async fetchWaves() {
        if (this.calendarDays.length === 0) {
            return;
        }
        const startDate = this.calendarDays[0].date;
        const endDate = this.calendarDays[this.calendarDays.length - 1].date;

        console.log(`Calendar.vue: fetchWaves() called for ${startDate} to ${endDate}`);
        try {
            // Coords for Wrightsville Beach, NC
            const response = await axios.get(`/api/waves/34.21/-77.80?start_date=${startDate}&end_date=${endDate}`);
            const waveData = response.data;
            const newWaves = {};
            if (waveData.daily) {
                waveData.daily.time.forEach((date, index) => {
                    newWaves[date] = waveData.daily.wave_height_max[index];
                });
            }
            this.waves = newWaves;
            console.log("Calendar.vue: Wave data fetched successfully", this.waves);
        } catch (error) {
            console.error('Error fetching wave data:', error);
        }
    },
    async saveEvent(event, date, position) {
      const content = event.target.innerText;
      if (this.events[date] && this.events[date][position] && this.events[date][position].content === content) {
          return;
      }
      
      try {
        const response = await axios.post('/api/events', {
          event_date: date,
          content: content,
          position: position,
        });

        const updatedEvents = { ...this.events };
        if (!updatedEvents[date]) {
          updatedEvents[date] = [];
        }
        updatedEvents[date][position] = response.data;
        this.events = updatedEvents;

        console.log("Calendar.vue: Event saved successfully");
      } catch (error) {
        console.error('Error saving event:', error);
      }
    },
    prevMonth() {
      console.log("Calendar.vue: prevMonth() called");
      this.currentDate = new Date(this.currentYear, this.currentMonth - 1, 1);
      this.fetchEvents();
    },
    nextMonth() {
      console.log("Calendar.vue: nextMonth() called");
      this.currentDate = new Date(this.currentYear, this.currentMonth + 1, 1);
      this.fetchEvents();
    },
    adjustFontSize() {
      this.$nextTick(() => {
        if (!this.$el) return;

        const eventPlaceholders = this.$el.querySelectorAll('.event-placeholder');
        eventPlaceholders.forEach(el => {
          // Calculate base font size from vertical space
          const placeholderHeight = el.clientHeight;
          if (placeholderHeight <= 0) return;

          // Set font size based on the placeholder's height
          const baseFontSize = placeholderHeight * 0.7; // 70% of the row height
          el.style.fontSize = `${baseFontSize}px`;

          // Adjust for horizontal overflow
          const parentWidth = el.clientWidth;
          const textWidth = el.scrollWidth;

          if (textWidth > parentWidth) {
            const scaleFactor = parentWidth / textWidth;
            // Apply the scaling factor to the font size
            el.style.fontSize = `${baseFontSize * scaleFactor}px`;
          }
        });
      });
    },
    async sendSummary() {
      try {
        const response = await axios.post('/api/summary/email');
        if (response.data.status === 'email_sent_successfully') {
          alert(`Email summary successfully sent to jeff@levensailor.com!`);
        } else {
          alert(`Failed to send email: ${response.data.details || response.data.error}`);
        }
      } catch (error) {
        console.error('Error sending summary:', error);
        alert('Failed to send summary. Check the console for details.');
      }
    },
  },
  watch: {
    currentDate: {
      handler() {
        console.log("Calendar.vue: currentDate changed, fetching events");
        this.fetchEvents();
        this.fetchFlights();
        this.fetchWaves();
      },
      immediate: false
    }
  },
  mounted() {
    console.log("Calendar.vue: mounted() called");
    window.addEventListener('resize', this.adjustFontSize);
    this.$nextTick(() => {
      this.fetchEvents();
      this.fetchWeather();
      this.fetchFlights();
      this.fetchWaves();
    });
  },
  beforeUnmount() {
    window.removeEventListener('resize', this.adjustFontSize);
  },
};
</script>

<style scoped>
.calendar {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.calendar-header {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  padding: 10px 0;
  background-color: #e0e0e0;
  text-align: center;
  font-weight: bold;
}

.calendar-grid {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  grid-auto-rows: 1fr;
  flex-grow: 1;
  gap: 1px;
  background-color: #ccc;
  border: 1px solid #ccc;
  min-height: 0;
}

.day-cell {
  background-color: #fff;
  display: flex;
  flex-direction: column;
  position: relative;
  overflow: hidden;
}

.day-cell.other-month {
  background-color: #f7f7f7;
  color: #aaa;
}

.day-header-icons {
  position: absolute;
  top: 2px;
  left: 5px;
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 8px;
  z-index: 1;
}

.flight-info, .wave-info {
  font-size: 0.8em;
  display: flex;
  align-items: center;
  gap: 4px;
  background: white;
  padding: 1px 3px;
  border-radius: 3px;
}

.wave-info svg {
    stroke: #007bff;
}

.day-number {
  position: absolute;
  top: 2px;
  right: 5px;
  font-size: 0.8em;
  z-index: 1;
  fill: #a3d4ff;
}

.events {
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  padding-top: 1.5em;
  position: relative;
  z-index: 2;
}

.event-placeholder {
  flex-grow: 1;
  border-top: 1px solid #eee;
  padding: 2px 4px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  line-height: 1.2;
}

.custody-row {
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  font-weight: bold;
  user-select: none; /* Prevents text selection on click */
}

.custody-jeff {
  background-color: #a3d4ff;
  color: #1c3d52;
}

.custody-deanna {
  background-color: #ffc0cb;
  color: #5c2c32;
}

.event-placeholder:empty::before {
    content: " ";
    white-space: pre;
}

.calendar-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background-color: #e0e0e0;
}

.footer-icons, .month-nav, .footer-actions {
  flex: 1;
}

.footer-icons {
  display: flex;
  justify-content: flex-start;
}

.month-nav {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 15px; /* Add space between items */
}

.custody-share {
  font-size: 0.8em;
  color: #555;
  padding-left: 15px;
  border-left: 1px solid #ccc;
  font-weight: bold;
}

.footer-actions {
  flex: 1;
  display: flex;
  justify-content: flex-end;
}

.footer-placeholder {
  /* To balance the flexbox layout */
}

.icon-button {
  background: none;
  border: none;
  cursor: pointer;
  padding: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.icon-button svg {
  stroke: #333;
  fill: none;
}

.icon-button svg.active {
  stroke: #007bff;
  fill: #a3d4ff;
}

.surfboard-toggle svg.active {
    stroke: #ff69b4; /* Hot pink */
    fill: #ffc0cb; /* Lighter pink */
}

.flight-toggle svg.active {
  stroke: #ffc107;
  fill: #fffde7;
}

.calendar-footer button {
  background: none;
  border: 1px solid #333;
  cursor: pointer;
  margin: 0 10px;
  padding: 5px 10px;
  font-family: 'Courier New', Courier, monospace;
}

.calendar-footer button:hover {
  background-color: #f0f0f0;
}
</style> 